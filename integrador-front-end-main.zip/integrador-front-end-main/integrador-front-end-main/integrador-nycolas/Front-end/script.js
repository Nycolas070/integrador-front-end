const modal = document.querySelector(".modal-container");
const tbody = document.querySelector("tbody");
const snome = document.querySelector("#m-nome");
const sPreco = document.querySelector("#m-preco");
const btnSalvar = document.querySelector("#btnSalvar");

let itens;
let nome;

function openModal(edit = false, index = 0) {
  modal.classList.add("active");

  modal.onclick = (e) => {
    if (e.target.className.indexOf("modal-container") !== -1) {
      modal.classList.remove("active");
    }
  };

  if (edit) {
    snome.value = itens[index].nome;
    sPreco.value = itens[index].preco;
    nome = index;
  } else {
    snome.value = "";
    sPreco.value = "";
    nome = undefined;
  }
}

function editItem(index) {
  openModal(true, index);
}

function confirmarExclusao(index) {
  var resposta = confirm("Você tem certeza que deseja excluir este item?");
  if (resposta == true) {
      deleteItem(index);
  } else {
      console.log("Exclusão cancelada.");
  }
}

function deleteItem(index) {
  itens.splice(index, 1);
  setItensBD();
  loadItens();
  console.log("Item excluído com sucesso!");
}

function insertItem(item, index) {
  let tr = document.createElement("tr");

  tr.innerHTML = `
    <td><img src="${item.imagem}" alt="Imagem do Item" style="max-width: 50px; max-height: 50px;" /></td>
    <td>${item.nome}</td>
    <td>${item.preco}</td>
    <td class="acao">
      <button onclick="editItem(${index})"><i class='bx bx-edit'></i></button>
    </td>
    <td class="acao">
      <button onclick="confirmarExclusao(${index})"><i class='bx bx-trash'></i></button>
    </td>
  `;
  tbody.appendChild(tr);
}

btnSalvar.onclick = (e) => {
  if (snome.value == "" || sPreco.value == "") {
    return;
  }

  e.preventDefault();

  const itemImage = document.getElementById('m-img').files[0]; 

  if (!itemImage) {
    alert("Por favor, carregue uma imagem.");
    return;
  }

  const reader = new FileReader();
  reader.onload = function (e) {
    const itemImageData = e.target.result;
    
    if (nome !== undefined) {
      itens[nome].nome = snome.value;
      itens[nome].preco = sPreco.value;
    } else {
      itens.push({
        nome: snome.value,
        preco: sPreco.value,
        imagem: itemImageData
      });
    }

    setItensBD();
    modal.classList.remove("active");
    loadItens();
  };

  reader.readAsDataURL(itemImage);
};

function loadItens() {
  itens = getItensBD();
  tbody.innerHTML = "";
  itens.forEach((item, index) => {
    insertItem(item, index);
  });
}

const getItensBD = () => JSON.parse(localStorage.getItem("dbfunc")) ?? [];
const setItensBD = () => localStorage.setItem("dbfunc", JSON.stringify(itens));

loadItens();


function virgula(event) {
  const campo = event.target;
  let valor = campo.value.replace(/\D/g, '');  

  if (valor.length > 9) {
    valor = valor.slice(0, 9);
  }

  if (valor.length > 7) {
    valor = valor.slice(0, 7) + ',' + valor.slice(7);
  }

  campo.value = valor;
}

document.getElementById('m-img').addEventListener('change', function (event) {
  const file = event.target.files[0];
  const preview = document.querySelector('#ItemImagePreview');
  if (file) {
    const reader = new FileReader();
    reader.onload = function (e) {
      preview.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }
});


fetch(local),{

}